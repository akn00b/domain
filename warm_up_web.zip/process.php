<?php

$cip=$_POST['flag'];
$txt="W3b_1s_E4sy_N4h";
if($cip == $txt)
{
  echo "<h1 align='center'>FL4G{E4sy_P33zy_Fl4g}</h1>";
}
else {
  echo "<h1 align='center'>Failed</h1>";
}

 ?>
